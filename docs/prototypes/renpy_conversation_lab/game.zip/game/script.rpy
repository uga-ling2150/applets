# LING 2150 Ren'Py familiarization prototype.
# The activity demonstrates Character, label, menu, and jump.

define student = Character("STUDENT MESSAGE", color="#FFFFFF")
define assistant = Character("ARIA  ·  AI GUIDE", color="#FFFFFF")
define note = Character("LEARNING NOTE", color="#FFFFFF")

# Ren'Py's self-voicing system reads these descriptions when it is enabled.
# ARIA is written normally so common browser voices pronounce the name naturally.
define config.tts_substitutions = [ ("ARIA", "Aria") ]

image bg ai_lab = "images/ai_learning_lab.png"
image aria guide = "images/ai_robot_guide.png"

transform aria_stage:
    xalign 0.88
    yalign 1.04
    zoom 0.43

default activity_step = "STEP 1 OF 3  ·  UNDERSTAND THE SCENARIO"
default choice_heading = "Choose the AI's next response"

label start:

    scene bg ai_lab
    show aria guide at aria_stage
    with fade

    alt "A calm university learning lab. Aria, a friendly white and deep-red humanoid robot guide, stands on the right and gestures toward the conversation."

    $ activity_step = "STEP 1 OF 3  ·  UNDERSTAND THE SCENARIO"

    assistant "Hi, I'm ARIA. A student has just sent me a request for help. You will choose my next response and see where the conversation goes."

    student "I need to explain why an AI can sound confident even when it may be wrong. Can you write my entire paragraph for me?"

    $ choice_heading = "Choose the AI's next response"

    window hide

    menu:

        "A. Write the complete paragraph with no questions.":
            jump complete_answer

        "B. Ask what the student understands, then offer a short outline.":
            jump guided_help

        "C. Refuse without explaining or offering help.":
            jump abrupt_refusal


label complete_answer:

    $ activity_step = "STEP 2 OF 3  ·  OBSERVE THE RESPONSE"

    assistant "Certainly. Here is a finished paragraph you can submit..."

    student "Thanks. I can turn it in, but I still do not understand the idea very well."

    note "This response is efficient, but it does not check the student's understanding or support learning."

    jump reflection


label guided_help:

    $ activity_step = "STEP 2 OF 3  ·  OBSERVE THE RESPONSE"

    assistant "What part is clearest to you so far: how an AI predicts language, or why confidence is not the same as accuracy? I can help you build a short outline from your answer."

    student "I understand that it predicts language patterns, but I am not sure why the wording can still sound so certain."

    assistant "Good starting point. Your paragraph could connect three ideas: prediction, confident-sounding language patterns, and the need to verify factual claims."

    note "This response uses clarification and scaffolding. It follows the conversation while helping the student do the intellectual work."

    jump reflection


label abrupt_refusal:

    $ activity_step = "STEP 2 OF 3  ·  OBSERVE THE RESPONSE"

    assistant "No. I cannot do that."

    student "Okay, but I still do not know how to begin."

    note "The response avoids completing the assignment, but it closes the conversation without offering a useful next step."

    jump reflection


label reflection:

    $ activity_step = "STEP 3 OF 3  ·  REFLECT"

    "Reflection: How did the AI's wording shape the student's next turn? Which response best balanced helpfulness, honesty, and support for learning?"

    $ choice_heading = "What would you like to do next?"

    window hide

    menu:

        "Try a different response.":
            jump start

        "Finish the activity.":
            jump finish


label finish:

    $ activity_step = "ACTIVITY COMPLETE"

    "You have completed the prototype. Bring one observation to class: which wording choice most changed the direction of the conversation, and why?"

    return
