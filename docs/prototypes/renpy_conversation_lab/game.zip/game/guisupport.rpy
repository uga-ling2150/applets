# Keep only the scale helper required by the generated GUI.
# The hidden SDK template also imports Launcher-only gui7 modules here;
# those modules are unavailable in standalone and web distributions.

init -100 python in gui:

    def scale(n):
        return int(n)
