# Game-like visual-novel interface for the LING 2150 branching conversation.

init offset = 10


################################################################################
## Main menu: a visual-novel title screen, not an applet landing page.
################################################################################

screen main_menu():

    tag menu

    add "images/ai_learning_lab.png"
    add Solid("#09090999")

    add "images/ai_robot_guide.png":
        xalign 0.88
        yalign 1.04
        zoom 0.43

    add Solid("#BA0C2F") xsize 12 ysize 720

    frame:
        xpos 72
        yalign 0.5
        xsize 610
        ysize 550
        background Solid("#101010E8")
        padding (48, 42)

        vbox:
            xfill True
            spacing 15

            text "LING 2150  ·  INTERACTIVE SCENARIO":
                style "game_kicker"

            text "CONVERSATION\nLAB":
                style "game_title"

            add Solid("#BA0C2F") xsize 100 ysize 6

            text "Helpfulness, honesty, and learning":
                style "game_subtitle"

            text "Meet ARIA, an AI guide. Choose what she should say to a student, then watch how the conversation changes.":
                style "game_body"

            null height 8

            textbutton "BEGIN SCENARIO  →":
                action Start()
                style "game_primary_button"

            textbutton "ABOUT / CONTROLS":
                action ShowMenu("about")
                style "game_secondary_button"

            text "CONTROLS  ·  Click/Space: continue  ·  V: self-voicing  ·  Shift+A: accessibility":
                style "game_controls"


################################################################################
## Small in-scene HUD
################################################################################

screen scenario_hud():

    frame:
        xpos 30
        ypos 26
        background Solid("#101010CC")
        padding (18, 10)

        hbox:
            spacing 14

            text "CONVERSATION 01":
                style "hud_label"

            text "[activity_step]":
                style "hud_step"


################################################################################
## Dialogue: character sprite and scene remain visible above a classic box.
################################################################################

screen say(who, what):

    use scenario_hud

    window:
        id "window"
        xalign 0.5
        yalign 1.0
        xsize 1220
        ysize 220
        background Solid("#101010EE")
        padding (42, 28)

        hbox:
            xfill True
            yfill True
            spacing 24

            add Solid("#BA0C2F") xsize 7 ysize 164

            vbox:
                xsize 1080
                spacing 10

                if who is not None:
                    text who id "who":
                        style "vn_speaker"
                else:
                    text "SCENARIO":
                        style "vn_speaker"

                text what id "what":
                    style "vn_dialogue"

                text "Click or press Space to continue  ›":
                    style "vn_continue"


################################################################################
## Choices: a translucent game overlay, with ARIA still present in the scene.
################################################################################

screen choice(items):

    modal True

    if len(items) == 3:
        key "K_a" action items[0].action
        key "K_b" action items[1].action
        key "K_c" action items[2].action
    elif len(items) == 2:
        key "K_1" action items[0].action
        key "K_2" action items[1].action

    add Solid("#00000066")

    use scenario_hud

    frame:
        xpos 54
        yalign 0.48
        xsize 760
        ysize 450
        background Solid("#101010F2")
        padding (38, 30)

        vbox:
            xfill True
            spacing 11

            text "YOUR CHOICE":
                style "game_kicker"

            text "[choice_heading]":
                style "choice_title"

            text ("Choose with mouse/touch or press A, B, or C." if len(items) == 3 else "Choose with mouse/touch or press 1 or 2."):
                style "choice_help"

            null height 4

            for i in items:
                textbutton i.caption:
                    action i.action
                    style "vn_choice_button"


################################################################################
## Minimal visual-novel quick controls
################################################################################

screen quick_menu():

    zorder 100

    if quick_menu:

        hbox:
            xalign 0.98
            yalign 0.015
            spacing 6

            textbutton "BACK" action Rollback() style "hud_button"
            textbutton "HISTORY" action ShowMenu("history") style "hud_button"


################################################################################
## Styles
################################################################################

style game_kicker is text:
    font gui.interface_text_font
    size 15
    bold True
    color "#F16C83"
    kerning 1

style game_title is text:
    font gui.interface_text_font
    size 62
    bold True
    color "#FFFFFF"
    line_spacing -8

style game_subtitle is text:
    font gui.interface_text_font
    size 24
    bold True
    color "#FFFFFF"

style game_body is text:
    font gui.interface_text_font
    size 21
    color "#E4DFDC"
    line_spacing 6
    xmaximum 500

style game_controls is text:
    font gui.interface_text_font
    size 13
    color "#C5BEB9"
    line_spacing 3
    xmaximum 500

style game_primary_button is button:
    xsize 330
    ysize 62
    background Solid("#BA0C2F")
    hover_background Solid("#E4002B")
    insensitive_background Solid("#6E6864")
    padding (24, 14)

style game_primary_button_text is button_text:
    font gui.interface_text_font
    size 19
    bold True
    color "#FFFFFF"
    hover_color "#FFFFFF"
    insensitive_color "#FFFFFF"
    xalign 0.5
    yalign 0.5

style game_secondary_button is button:
    xsize 330
    ysize 50
    background Solid("#FFFFFF1C")
    hover_background Solid("#FFFFFF33")
    padding (22, 11)

style game_secondary_button_text is button_text:
    font gui.interface_text_font
    size 16
    bold True
    color "#FFFFFF"
    hover_color "#FFFFFF"
    xalign 0.5
    yalign 0.5

style hud_label is text:
    font gui.interface_text_font
    size 14
    bold True
    color "#FFFFFF"

style hud_step is text:
    font gui.interface_text_font
    size 14
    bold True
    color "#F16C83"

style hud_button is button:
    background Solid("#101010B8")
    hover_background Solid("#BA0C2F")
    padding (12, 7)

style hud_button_text is button_text:
    font gui.interface_text_font
    size 12
    bold True
    color "#FFFFFF"
    hover_color "#FFFFFF"

style vn_speaker is text:
    font gui.name_text_font
    size 22
    bold True
    color "#F16C83"

style vn_dialogue is text:
    font gui.text_font
    size 25
    color "#FFFFFF"
    line_spacing 7
    xmaximum 1060

style vn_continue is text:
    font gui.interface_text_font
    size 14
    bold True
    color "#C5BEB9"
    xalign 1.0

style choice_title is text:
    font gui.interface_text_font
    size 30
    bold True
    color "#FFFFFF"

style choice_help is text:
    font gui.interface_text_font
    size 15
    color "#C5BEB9"

style vn_choice_button is button:
    xfill True
    yminimum 75
    background Solid("#FFFFFF18")
    hover_background Solid("#BA0C2F")
    selected_background Solid("#BA0C2F")
    insensitive_background Solid("#FFFFFF0C")
    padding (22, 14)

style vn_choice_button_text is button_text:
    font gui.interface_text_font
    size 19
    color "#FFFFFF"
    hover_color "#FFFFFF"
    selected_color "#FFFFFF"
    insensitive_color "#8D8783"
    xalign 0.0
    yalign 0.5
    line_spacing 4

# Required `who` and `what` ids automatically receive these styles.
style say_label is vn_speaker:
    xpos 0
    ypos 0
    xalign 0.0

style say_dialogue is vn_dialogue:
    xpos 0
    ypos 0
    xsize 1060
    xalign 0.0
