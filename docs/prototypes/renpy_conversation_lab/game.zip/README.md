# LING 2150 Ren'Py familiarization prototype

This small prototype demonstrates a classroom-related branching conversation in Ren'Py. The learner plays an AI assistant responding to a student who asks for help with a course paragraph.

The interface is designed as a small visual-novel game rather than a course applet. The learner meets **ARIA**, an original AI robot guide, inside an illustrated campus learning lab. Dialogue appears in a classic bottom-of-screen text box, choices appear as an overlay on the scene, and ARIA remains visible while the conversation branches. The first choice also supports the `A`, `B`, and `C` keyboard shortcuts.

The restrained red, black, white, and warm-gray palette keeps a connection to LING 2150 without copying the layout of the course's HTML applets.

## Concepts demonstrated

- `Character`: names the Student, AI Assistant, and Teaching Note speakers.
- `label`: divides the script into the opening, three response paths, reflection, and finish.
- `menu`: presents the three AI responses and the replay/finish choice.
- `jump`: routes the learner to a selected response path and then to reflection.

The main learning script is `game/script.rpy`.

## Run and build

1. Open Ren'Py Launcher.
2. Add this project directory if it is not already listed.
3. Select **LING 2150: How Should an AI Respond?** and choose **Launch Project**.
4. Under **Web (Beta)**, choose **Build Web Application** or **Build and Open in Browser**.

For web hosting, upload every file in the generated web directory together. The application must be served through HTTP(S); opening `index.html` directly from the filesystem is not supported.

## Accessibility note

Ren'Py includes self-voicing (`V`) and an accessibility menu (`Shift+A`). The Web export renders the activity primarily inside a canvas, so an automated DOM scan cannot verify the dialogue and choices in the same way it can verify semantic HTML. Keyboard, self-voicing, contrast, zoom, and screen-reader behavior require manual testing before classroom deployment.
